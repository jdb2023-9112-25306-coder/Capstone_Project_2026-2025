# AquaWell API (PHP)

Backend for the AquaWell web system. PHP 8.1+ (XAMPP PHP 8.2 works), MySQL 8 / MariaDB, PDO.

## Setup
1. Import `database/aquawell_db.sql` into MySQL (MySQL Workbench).
2. Edit `database/create_api_user.sql` (set your own password) and run it as root.
3. Copy this folder into `<xampp>/htdocs/aquawell_api`.
4. In `config/`, copy `config.sample.php` to `config.local.php` and set the same password.
5. Start Apache in XAMPP and open `http://localhost:8080/aquawell_api/health.php`
   (use your own Apache port). Expect `{"success":true,...,"database":"connected"}`.

## Endpoints (JSON in, JSON out; send `Content-Type: application/json`)
| Method | File | Purpose |
|---|---|---|
| GET | `health.php` | API and database connection check |
| POST | `register.php` | Customer sign-up (starts a session). Fields: firstName, lastName, middleName?, email, password, contactNumber, address, barangay?, landmark? |
| POST | `login.php` | Customer or staff login. Fields: email, password |
| GET | `me.php` | Current logged-in user (401 if none) |
| POST | `logout.php` | Ends the session |

Success: `{"success": true, "user": {...}}`. Errors: `{"success": false, "error": "..."}`
with status 400/401/405/409/415/422/429/500. `user.role` is `customer`, `admin`, `staff` or `delivery`.
The browser app must send requests with `credentials: 'include'` so the session cookie is used.

## Security notes
- Passwords are stored with bcrypt (`password_hash`); never plain text.
- All queries use prepared statements; the API connects with a limited user, not root.
- Login is throttled (5 failed attempts per email and IP in 15 minutes) and every login,
  failed login, logout and registration is written to `activity_log`.
- `config/` and `lib/` are blocked from the web by `.htaccess`; `config.local.php` is git-ignored.
