<?php
declare(strict_types=1);
require __DIR__ . '/lib/bootstrap.php';
aw_boot();
aw_require_method('POST');

$user = aw_current_user();
if ($user !== null) {
    aw_log($user['type'] === 'customer' ? 'Customer' : 'Staff', $user['id'], 'LOGOUT', $user['email']);
}
aw_destroy_session();
aw_json(200, ['success' => true]);
