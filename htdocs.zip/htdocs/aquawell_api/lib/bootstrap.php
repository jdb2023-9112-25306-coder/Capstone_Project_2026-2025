<?php
declare(strict_types=1);

/**
 * AquaWell API - shared helpers (Module 02, Step 2). Requires PHP 8.1+.
 * Every endpoint calls aw_boot() first.
 */

// A real bcrypt hash used only to keep login timing the same when the email is unknown.
const AW_DUMMY_HASH = '$2y$10$bfKhwr/VXNRDQrCdTOKTIeJ53vLanfEgVUwmsZ5txV7AAIXEe1fii';

/** Character-aware string helpers that still work if the mbstring extension is off. */
function aw_strlen(string $s): int
{
    return function_exists('mb_strlen') ? mb_strlen($s) : strlen($s);
}

function aw_substr(string $s, int $start, int $length): string
{
    return function_exists('mb_substr') ? mb_substr($s, $start, $length) : substr($s, $start, $length);
}

function aw_config(): array
{
    static $cfg = null;
    if ($cfg === null) {
        $file = __DIR__ . '/../config/config.local.php';
        if (!is_file($file)) {
            http_response_code(500);
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(['success' => false, 'error' => 'API is not configured: copy config/config.sample.php to config/config.local.php.']);
            exit;
        }
        $cfg = require $file;
    }
    return $cfg;
}

function aw_boot(): void
{
    $cfg = aw_config();
    ini_set('display_errors', '0');
    header('Content-Type: application/json; charset=utf-8');
    header('X-Content-Type-Options: nosniff');
    header('Cache-Control: no-store');

    set_exception_handler(function (Throwable $e) use ($cfg): void {
        error_log('[aquawell_api] ' . get_class($e) . ': ' . $e->getMessage());
        if (!headers_sent()) {
            http_response_code(500);
        }
        $body = ['success' => false, 'error' => 'Server error. Please try again.'];
        if (!empty($cfg['debug'])) {
            $body['debug'] = $e->getMessage();
        }
        echo json_encode($body);
    });

    // CORS: only origins listed in the config may call the API with cookies.
    $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
    if ($origin !== '' && in_array($origin, $cfg['allowed_origins'], true)) {
        header('Access-Control-Allow-Origin: ' . $origin);
        header('Access-Control-Allow-Credentials: true');
        header('Access-Control-Allow-Headers: Content-Type');
        header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
        header('Vary: Origin');
    }
    if (($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') {
        http_response_code(204);
        exit;
    }
}

function aw_json(int $status, array $body): never
{
    http_response_code($status);
    echo json_encode($body, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function aw_fail(int $status, string $message, array $extra = []): never
{
    aw_json($status, ['success' => false, 'error' => $message] + $extra);
}

function aw_require_method(string $method): void
{
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== $method) {
        header('Allow: ' . $method);
        aw_fail(405, 'Method not allowed.');
    }
}

/** Reads a JSON body. Requiring application/json also blocks simple cross-site form posts (CSRF). */
function aw_read_json(): array
{
    $type = $_SERVER['CONTENT_TYPE'] ?? '';
    if (stripos($type, 'application/json') !== 0) {
        aw_fail(415, 'Content-Type must be application/json.');
    }
    $raw = file_get_contents('php://input');
    if ($raw === false || strlen($raw) > 65536) {
        aw_fail(413, 'Request body is too large.');
    }
    $data = json_decode($raw, true);
    if (!is_array($data)) {
        aw_fail(400, 'Invalid JSON body.');
    }
    return $data;
}

function aw_client_ip(): string
{
    return (string)($_SERVER['REMOTE_ADDR'] ?? '');
}

function aw_db(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        $db = aw_config()['db'];
        $dsn = sprintf('mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4', $db['host'], (int)$db['port'], $db['name']);
        $pdo = new PDO($dsn, $db['user'], $db['pass'], [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false, // real prepared statements
        ]);
    }
    return $pdo;
}

/** Audit trail (IAS plan). A logging failure never breaks the request. */
function aw_log(string $actorType, ?int $actorId, string $action, ?string $details = null): void
{
    try {
        $st = aw_db()->prepare('INSERT INTO activity_log (actor_type, actor_id, action, details, ip_address) VALUES (?, ?, ?, ?, ?)');
        $st->execute([$actorType, $actorId, $action, $details === null ? null : aw_substr($details, 0, 255), aw_client_ip()]);
    } catch (Throwable $e) {
        error_log('[aquawell_api] log failed: ' . $e->getMessage());
    }
}

function aw_session_start(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }
    $cfg = aw_config();
    ini_set('session.use_strict_mode', '1');
    session_name('AQUAWELL_SID');
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'secure'   => (bool)$cfg['cookie_secure'],
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
    $idle = max(1, (int)$cfg['session_idle_minutes']) * 60;
    if (isset($_SESSION['last_seen']) && time() - (int)$_SESSION['last_seen'] > $idle) {
        $_SESSION = [];
        session_destroy();
        session_start();
    }
    $_SESSION['last_seen'] = time();
}

function aw_login_session(string $type, int $id): void
{
    aw_session_start();
    session_regenerate_id(true); // new session id at login (prevents session fixation)
    $_SESSION['utype'] = $type;
    $_SESSION['uid'] = $id;
    $_SESSION['last_seen'] = time();
}

function aw_destroy_session(): void
{
    aw_session_start();
    $_SESSION = [];
    $p = session_get_cookie_params();
    setcookie(session_name(), '', [
        'expires'  => time() - 3600,
        'path'     => $p['path'],
        'domain'   => $p['domain'],
        'secure'   => $p['secure'],
        'httponly' => $p['httponly'],
        'samesite' => 'Lax',
    ]);
    session_destroy();
}

function aw_public_customer(array $r): array
{
    return [
        'id'              => (int)$r['customer_id'],
        'type'            => 'customer',
        'role'            => 'customer',
        'firstName'       => $r['first_name'],
        'lastName'        => $r['last_name'],
        'name'            => trim($r['first_name'] . ' ' . $r['last_name']),
        'email'           => $r['email'],
        'phone'           => $r['contact_number'],
        'address'         => $r['address'],
        'barangay'        => $r['barangay'],
        'landmark'        => $r['landmark'],
        'bottlesBorrowed' => (int)$r['bottles_borrowed'],
    ];
}

function aw_public_staff(array $r): array
{
    return [
        'id'        => (int)$r['staff_id'],
        'type'      => 'staff',
        'role'      => strtolower($r['role']), // admin | staff | delivery
        'firstName' => $r['first_name'],
        'lastName'  => $r['last_name'],
        'name'      => trim($r['first_name'] . ' ' . $r['last_name']),
        'email'     => $r['email'],
        'phone'     => $r['contact_number'],
    ];
}

/** The logged-in user, re-read from the database (so deactivated staff lose access at once). */
function aw_current_user(): ?array
{
    aw_session_start();
    if (empty($_SESSION['utype']) || empty($_SESSION['uid'])) {
        return null;
    }
    $pdo = aw_db();
    if ($_SESSION['utype'] === 'customer') {
        $st = $pdo->prepare('SELECT * FROM customer WHERE customer_id = ?');
        $st->execute([$_SESSION['uid']]);
        $row = $st->fetch();
        if ($row) {
            return aw_public_customer($row);
        }
    } else {
        $st = $pdo->prepare('SELECT * FROM staff WHERE staff_id = ? AND is_active = 1');
        $st->execute([$_SESSION['uid']]);
        $row = $st->fetch();
        if ($row) {
            return aw_public_staff($row);
        }
    }
    aw_destroy_session();
    return null;
}
