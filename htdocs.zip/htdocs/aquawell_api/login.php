<?php
declare(strict_types=1);
require __DIR__ . '/lib/bootstrap.php';
aw_boot();
aw_require_method('POST');
$cfg = aw_config();
$in = aw_read_json();

$email    = aw_substr(strtolower(trim((string)($in['email'] ?? ''))), 0, 100);
$password = (string)($in['password'] ?? '');
if ($email === '' || $password === '') {
    aw_fail(422, 'Email and password are required.');
}

$pdo = aw_db();
$ip = aw_client_ip();
$window = max(1, (int)$cfg['login_window_minutes']);

// Throttle: too many recent failures from this IP (for this email, or overall).
$st = $pdo->prepare(
    "SELECT COUNT(*) AS for_ip, COALESCE(SUM(details = ?), 0) AS for_email
       FROM activity_log
      WHERE action = 'LOGIN_FAILED' AND ip_address = ?
        AND created_at > (NOW() - INTERVAL $window MINUTE)"
);
$st->execute([$email, $ip]);
$t = $st->fetch();
if ((int)$t['for_email'] >= (int)$cfg['login_max_attempts'] || (int)$t['for_ip'] >= (int)$cfg['login_max_attempts_per_ip']) {
    header('Retry-After: ' . ($window * 60));
    aw_fail(429, 'Too many failed attempts. Please try again later.');
}

// Customers first, then active staff (admin, staff, delivery).
$type = null;
$row = null;
$st = $pdo->prepare('SELECT * FROM customer WHERE email = ?');
$st->execute([$email]);
if ($r = $st->fetch()) {
    $type = 'customer';
    $row = $r;
} else {
    $st = $pdo->prepare('SELECT * FROM staff WHERE email = ? AND is_active = 1');
    $st->execute([$email]);
    if ($r = $st->fetch()) {
        $type = 'staff';
        $row = $r;
    }
}

// Always run password_verify, so an unknown email takes as long as a wrong password.
$valid = password_verify($password, $row['password_hash'] ?? AW_DUMMY_HASH);
if ($row === null || !$valid) {
    aw_log('System', null, 'LOGIN_FAILED', $email);
    aw_fail(401, 'Invalid email or password.');
}

if (password_needs_rehash($row['password_hash'], PASSWORD_BCRYPT)) {
    $sql = $type === 'customer'
        ? 'UPDATE customer SET password_hash = ? WHERE customer_id = ?'
        : 'UPDATE staff SET password_hash = ? WHERE staff_id = ?';
    $pdo->prepare($sql)->execute([password_hash($password, PASSWORD_BCRYPT), $row[$type === 'customer' ? 'customer_id' : 'staff_id']]);
}

if ($type === 'customer') {
    $id = (int)$row['customer_id'];
    $user = aw_public_customer($row);
    $actor = 'Customer';
} else {
    $id = (int)$row['staff_id'];
    $user = aw_public_staff($row);
    $actor = 'Staff';
}

aw_login_session($type, $id);
aw_log($actor, $id, 'LOGIN', $email);
aw_json(200, ['success' => true, 'user' => $user]);
