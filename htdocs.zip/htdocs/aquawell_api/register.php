<?php
declare(strict_types=1);
require __DIR__ . '/lib/bootstrap.php';
aw_boot();
aw_require_method('POST');
$in = aw_read_json();

$first    = trim((string)($in['firstName'] ?? ''));
$last     = trim((string)($in['lastName'] ?? ''));
$middle   = trim((string)($in['middleName'] ?? ''));
$email    = strtolower(trim((string)($in['email'] ?? '')));
$password = (string)($in['password'] ?? '');
$phone    = trim((string)($in['contactNumber'] ?? ''));
$address  = trim((string)($in['address'] ?? ''));
$barangay = trim((string)($in['barangay'] ?? ''));
$landmark = trim((string)($in['landmark'] ?? ''));

$errors = [];
if ($first === '' || aw_strlen($first) > 50)  { $errors['firstName'] = 'First name is required (max 50 characters).'; }
if ($last === '' || aw_strlen($last) > 50)    { $errors['lastName'] = 'Last name is required (max 50 characters).'; }
if (aw_strlen($middle) > 50)                  { $errors['middleName'] = 'Middle name is too long (max 50 characters).'; }
if (!filter_var($email, FILTER_VALIDATE_EMAIL) || aw_strlen($email) > 100) {
    $errors['email'] = 'Enter a valid email address.';
}
if (strlen($password) < 8)                    { $errors['password'] = 'Password must be at least 8 characters.'; }
elseif (strlen($password) > 72)               { $errors['password'] = 'Password must be at most 72 characters.'; } // bcrypt limit
elseif (strtolower($password) === $email)     { $errors['password'] = 'Password must not be the same as your email.'; }
if (!preg_match('/^[0-9+\-\s()]{7,20}$/', $phone)) {
    $errors['contactNumber'] = 'Enter a valid contact number.';
}
if ($address === '' || aw_strlen($address) > 255) { $errors['address'] = 'Address is required (max 255 characters).'; }
if (aw_strlen($barangay) > 100)               { $errors['barangay'] = 'Barangay is too long (max 100 characters).'; }
if (aw_strlen($landmark) > 150)               { $errors['landmark'] = 'Landmark is too long (max 150 characters).'; }
if ($errors) {
    aw_fail(422, 'Please fix the highlighted fields.', ['errors' => $errors]);
}

$pdo = aw_db();
$st = $pdo->prepare('SELECT 1 FROM customer WHERE email = ? UNION SELECT 1 FROM staff WHERE email = ?');
$st->execute([$email, $email]);
if ($st->fetch()) {
    aw_fail(409, 'An account with this email already exists.');
}

try {
    $st = $pdo->prepare(
        'INSERT INTO customer (last_name, first_name, middle_name, address, barangay, landmark, contact_number, email, password_hash)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
    );
    $st->execute([
        $last, $first, $middle === '' ? null : $middle, $address,
        $barangay === '' ? null : $barangay, $landmark === '' ? null : $landmark,
        $phone, $email, password_hash($password, PASSWORD_BCRYPT),
    ]);
} catch (PDOException $e) {
    if ($e->getCode() === '23000') { // two requests registered the same email at once
        aw_fail(409, 'An account with this email already exists.');
    }
    throw $e;
}
$id = (int)$pdo->lastInsertId();

$st = $pdo->prepare('SELECT * FROM customer WHERE customer_id = ?');
$st->execute([$id]);
$user = aw_public_customer($st->fetch());

aw_login_session('customer', $id);
aw_log('Customer', $id, 'REGISTER', $email);
aw_json(201, ['success' => true, 'user' => $user]);
