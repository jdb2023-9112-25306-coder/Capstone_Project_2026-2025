<?php
declare(strict_types=1);
require __DIR__ . '/lib/bootstrap.php';
aw_boot();
aw_require_method('GET');

try {
    aw_db()->query('SELECT 1');
} catch (Throwable $e) {
    error_log('[aquawell_api] health check failed: ' . $e->getMessage());
    aw_fail(503, 'Database unavailable.', ['service' => 'aquawell_api', 'database' => 'unavailable']);
}
aw_json(200, ['success' => true, 'service' => 'aquawell_api', 'database' => 'connected']);
