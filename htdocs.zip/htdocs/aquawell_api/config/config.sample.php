<?php
/**
 * Copy this file to config.local.php and fill in your own values.
 * config.local.php is ignored by Git so passwords never reach the repository.
 */
return [
    'db' => [
        'host' => '127.0.0.1',
        'port' => 3306,                 // MySQL80 default; change if yours differs
        'name' => 'aquawell_db',
        'user' => 'aquawell_app',       // limited user, NOT root (see create_api_user.sql)
        'pass' => 'Aquawell_2026',
    ],
    // React dev server origins allowed to call this API (with cookies).
    'allowed_origins' => [
        'http://localhost:5173',
        'http://127.0.0.1:5173',
    ],
    'cookie_secure'             => false, // set true when the site is served over HTTPS
    'session_idle_minutes'      => 30,
    'login_window_minutes'      => 15,
    'login_max_attempts'        => 5,     // failed logins per email + IP within the window
    'login_max_attempts_per_ip' => 20,    // failed logins per IP within the window
    'debug'                     => false, // true shows error details in responses (development only)
];
