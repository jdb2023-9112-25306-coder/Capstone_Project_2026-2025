<?php
declare(strict_types=1);
require __DIR__ . '/lib/bootstrap.php';
aw_boot();
aw_require_method('GET');

$user = aw_current_user();
if ($user === null) {
    aw_fail(401, 'Not logged in.');
}
aw_json(200, ['success' => true, 'user' => $user]);
