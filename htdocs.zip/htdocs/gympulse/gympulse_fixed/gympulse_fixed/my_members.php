<?php
$pageId    = 'my-members';
$pageTitle = 'My Members';
require_once __DIR__ . '/includes/header.php';
requireRole('trainer');

$pdo = getDB();

// Find the trainer record linked to this user account (matched by name)
$trainerRow = $pdo->prepare("SELECT id FROM trainers WHERE full_name = ? LIMIT 1");
$trainerRow->execute([$user['full_name']]);
$trainer = $trainerRow->fetch();
$trainerId = $trainer ? (int)$trainer['id'] : 0;

// Members assigned to this trainer
$members = [];
if ($trainerId) {
    $stmt = $pdo->prepare("
        SELECT m.*, CONCAT(m.first_name,' ',m.last_name) AS full_name,
               p.plan_name,
               (SELECT a.attendance_date FROM attendance a WHERE a.member_id=m.id ORDER BY a.id DESC LIMIT 1) AS last_visit
        FROM members m
        LEFT JOIN membership_plans p ON m.plan_id=p.id
        WHERE m.trainer_id = ?
        ORDER BY m.id DESC
    ");
    $stmt->execute([$trainerId]);
    $members = $stmt->fetchAll();
}

// Attendance log for this trainer's members only
$attendance = [];
if ($trainerId) {
    $stmt = $pdo->prepare("
        SELECT a.log_code, CONCAT(m.first_name,' ',m.last_name) AS member_name,
               m.member_code, a.attendance_date, a.time_in, a.time_out,
               a.duration_minutes, a.status
        FROM attendance a
        INNER JOIN members m ON a.member_id = m.id AND m.trainer_id = ?
        ORDER BY a.id DESC
        LIMIT 50
    ");
    $stmt->execute([$trainerId]);
    $attendance = $stmt->fetchAll();
}

function statusBadge($s) {
    $map = ['Active'=>'status-active','Pending'=>'status-pending','Expired'=>'status-expired',
            'Present'=>'status-present','Absent'=>'status-absent'];
    return '<span class="status-badge '.($map[$s]??'').'">'.htmlspecialchars($s).'</span>';
}
function fmtTime($t) { return $t ? date('g:i A', strtotime($t)) : '—'; }
function fmtDur($m)  { return $m ? floor($m/60).'h '.($m%60).'m' : '—'; }
?>

<div class="page active">
  <div class="section-head">
    <h3>My Members</h3>
    <span style="font-size:12px;color:var(--muted);">Showing members assigned to you only</span>
  </div>

  <?php if (!$trainerId): ?>
    <div style="background:var(--surface);border:1px solid var(--border);border-radius:12px;padding:28px;text-align:center;color:var(--muted);">
      ⚠️ Your trainer profile has not been linked yet. Please ask the admin to match your account name with a trainer record.
    </div>
  <?php elseif (!$members): ?>
    <div style="background:var(--surface);border:1px solid var(--border);border-radius:12px;padding:28px;text-align:center;color:var(--muted);">
      No members assigned to you yet.
    </div>
  <?php else: ?>
    <!-- KPI strip -->
    <div class="kpi-grid" style="grid-template-columns:repeat(3,1fr);margin-bottom:20px;">
      <div class="kpi-card">
        <div class="kpi-icon">👥</div>
        <div class="kpi-val"><?= count($members) ?></div>
        <div class="kpi-label">Assigned Members</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-icon">✅</div>
        <div class="kpi-val"><?= count(array_filter($members, fn($m)=>$m['status']==='Active')) ?></div>
        <div class="kpi-label">Active</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-icon">⏰</div>
        <div class="kpi-val"><?= count(array_filter($members, fn($m)=>$m['status']==='Expired')) ?></div>
        <div class="kpi-label">Expired</div>
      </div>
    </div>

    <!-- Members table -->
    <div class="table-wrap" style="margin-bottom:24px;">
      <table>
        <thead><tr><th>Member ID</th><th>Name</th><th>Plan</th><th>Last Visit</th><th>Status</th></tr></thead>
        <tbody>
          <?php foreach ($members as $m): ?>
          <tr>
            <td><?= htmlspecialchars($m['member_code']) ?></td>
            <td><?= htmlspecialchars($m['full_name']) ?></td>
            <td><?= htmlspecialchars($m['plan_name'] ?? 'N/A') ?></td>
            <td><?= $m['last_visit'] ? date('M j, Y', strtotime($m['last_visit'])) : '—' ?></td>
            <td><?= statusBadge($m['status']) ?></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <!-- Attendance log for my members -->
    <div class="section-head"><h3>Attendance Log — My Members</h3></div>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Log ID</th><th>Member</th><th>Date</th><th>Time In</th><th>Time Out</th><th>Duration</th><th>Status</th></tr></thead>
        <tbody>
          <?php if ($attendance): ?>
            <?php foreach ($attendance as $a): ?>
            <tr>
              <td><?= htmlspecialchars($a['log_code']) ?></td>
              <td><?= htmlspecialchars($a['member_name']) ?> <span style="color:var(--muted);font-size:11px;">(<?= htmlspecialchars($a['member_code']) ?>)</span></td>
              <td><?= date('M j, Y', strtotime($a['attendance_date'])) ?></td>
              <td><?= fmtTime($a['time_in']) ?></td>
              <td><?= fmtTime($a['time_out']) ?></td>
              <td><?= fmtDur($a['duration_minutes']) ?></td>
              <td><?= statusBadge($a['status']) ?></td>
            </tr>
            <?php endforeach; ?>
          <?php else: ?>
            <tr><td colspan="7" style="text-align:center;color:var(--muted);padding:20px;">No attendance records yet.</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
