<?php
$pageId    = 'dashboard';
$pageTitle = 'Dashboard';
require_once __DIR__ . '/includes/header.php';

$pdo = getDB();

// Show access denied message if redirected
if (isset($_GET['denied'])): ?>
<script>document.addEventListener('DOMContentLoaded',()=>showToast('Access Denied','You do not have permission to view that page.'));</script>
<?php endif; ?>

// KPIs — scoped by role
if (isTrainer()) {
    // Trainer sees only their own members
    $trainerRow2 = $pdo->prepare("SELECT id FROM trainers WHERE full_name = ? LIMIT 1");
    $trainerRow2->execute([$user['full_name']]);
    $myTrainer = $trainerRow2->fetch();
    $myTid = $myTrainer ? (int)$myTrainer['id'] : 0;

    $activeMembers = $myTid ? $pdo->prepare("SELECT COUNT(*) FROM members WHERE trainer_id=? AND status='Active'") : null;
    if ($activeMembers) { $activeMembers->execute([$myTid]); $activeMembers = $activeMembers->fetchColumn(); } else { $activeMembers = 0; }

    $presentToday = $myTid ? $pdo->prepare("SELECT COUNT(*) FROM attendance a INNER JOIN members m ON a.member_id=m.id AND m.trainer_id=? WHERE a.attendance_date=CURDATE() AND a.status='Present'") : null;
    if ($presentToday) { $presentToday->execute([$myTid]); $presentToday = $presentToday->fetchColumn(); } else { $presentToday = 0; }

    $monthRevenue  = null; // trainers don't see revenue
    $expiringSoon  = $myTid ? $pdo->prepare("SELECT COUNT(*) FROM enrollments e INNER JOIN members m ON e.member_id=m.id AND m.trainer_id=? WHERE e.expiry_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY) AND e.status='Active'") : null;
    if ($expiringSoon) { $expiringSoon->execute([$myTid]); $expiringSoon = $expiringSoon->fetchColumn(); } else { $expiringSoon = 0; }

    $recentMembers = $myTid ? $pdo->prepare("
        SELECT m.member_code, CONCAT(m.first_name,' ',m.last_name) AS full_name,
               p.plan_name, IFNULL(t.full_name,'Unassigned') AS trainer_name,
               m.joined_date, m.status
        FROM members m
        LEFT JOIN membership_plans p ON m.plan_id=p.id
        LEFT JOIN trainers t ON m.trainer_id=t.id
        WHERE m.trainer_id = ?
        ORDER BY m.id DESC LIMIT 5
    ") : null;
    if ($recentMembers) { $recentMembers->execute([$myTid]); $recentMembers = $recentMembers->fetchAll(); } else { $recentMembers = []; }

} else {
    // Admin and staff see full gym stats
    $activeMembers = $pdo->query("SELECT COUNT(*) FROM members WHERE status='Active'")->fetchColumn();
    $presentToday  = $pdo->query("SELECT COUNT(*) FROM attendance WHERE attendance_date=CURDATE() AND status='Present'")->fetchColumn();
    $totalToday    = $pdo->query("SELECT COUNT(*) FROM attendance WHERE attendance_date=CURDATE()")->fetchColumn();
    $monthRevenue  = $pdo->query("SELECT IFNULL(SUM(amount),0) FROM payments WHERE MONTH(payment_date)=MONTH(CURDATE()) AND YEAR(payment_date)=YEAR(CURDATE()) AND status='Paid'")->fetchColumn();
    $expiringSoon  = $pdo->query("SELECT COUNT(*) FROM enrollments WHERE expiry_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY) AND status='Active'")->fetchColumn();

    $recentMembers = $pdo->query("
        SELECT m.member_code, CONCAT(m.first_name,' ',m.last_name) AS full_name,
               p.plan_name, IFNULL(t.full_name,'Unassigned') AS trainer_name,
               m.joined_date, m.status
        FROM members m
        LEFT JOIN membership_plans p ON m.plan_id=p.id
        LEFT JOIN trainers t ON m.trainer_id=t.id
        ORDER BY m.id DESC LIMIT 5
    ")->fetchAll();
}
?>

<div class="page active" id="page-dashboard">
  <div class="kpi-grid">
    <div class="kpi-card">
      <div class="kpi-badge">Active</div>
      <div class="kpi-icon">👥</div>
      <div class="kpi-val"><?= number_format($activeMembers) ?></div>
      <div class="kpi-label"><?= isTrainer() ? 'My Active Members' : 'Active Members' ?></div>
    </div>
    <div class="kpi-card">
      <div class="kpi-icon">✅</div>
      <div class="kpi-val"><?= $presentToday ?></div>
      <div class="kpi-label"><?= isTrainer() ? 'My Members Present Today' : 'Present Today' ?></div>
    </div>
    <?php if (!isTrainer()): ?>
    <div class="kpi-card">
      <div class="kpi-badge">This Month</div>
      <div class="kpi-icon">💰</div>
      <div class="kpi-val">₱<?= number_format($monthRevenue / 1000, 0) ?>K</div>
      <div class="kpi-label">Monthly Revenue</div>
    </div>
    <?php endif; ?>
    <div class="kpi-card">
      <div class="kpi-badge warn">⏰ Alert</div>
      <div class="kpi-icon">⏰</div>
      <div class="kpi-val"><?= $expiringSoon ?></div>
      <div class="kpi-label"><?= isTrainer() ? 'My Members Expiring (30 days)' : 'Expiring in 30 Days' ?></div>
    </div>
  </div>

  <div class="section-head">
    <h3><?= isTrainer() ? 'My Members' : 'Recent Member Registrations' ?></h3>
    <a class="btn btn-outline btn-sm" href="<?= isTrainer() ? 'my_members.php' : 'members.php' ?>">View all →</a>
  </div>
  <div class="table-wrap">
    <table>
      <thead><tr><th>Member ID</th><th>Name</th><th>Plan</th><th>Trainer</th><th>Date Joined</th><th>Status</th></tr></thead>
      <tbody>
        <?php foreach ($recentMembers as $m): ?>
        <tr>
          <td><?= htmlspecialchars($m['member_code']) ?></td>
          <td><?= htmlspecialchars($m['full_name']) ?></td>
          <td><?= htmlspecialchars($m['plan_name'] ?? 'N/A') ?></td>
          <td><?= htmlspecialchars($m['trainer_name']) ?></td>
          <td><?= date('M j, Y', strtotime($m['joined_date'])) ?></td>
          <td><?= statusBadge($m['status']) ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php
function statusBadge($s) {
    $map = ['Active'=>'status-active','Pending'=>'status-pending','Expired'=>'status-expired','Paid'=>'status-paid','Unpaid'=>'status-unpaid','Present'=>'status-present','Absent'=>'status-absent','On Leave'=>'status-pending'];
    return '<span class="status-badge '.($map[$s]??'').'">'.htmlspecialchars($s).'</span>';
}

require_once __DIR__ . '/includes/footer.php';
?>
